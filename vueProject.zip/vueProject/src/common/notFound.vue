<template>
    <div class="contain">
    	<Icon type="ios-alert" size="50" color='black' class='icon'/>404
                   <p>你要访问的页面去旅游了。。。。 </p>
        
    </div>
    
</template>
<script>
export default {
    data(){
        return{
           
        }
    }
}
</script>
<style scoped>
    .contain{
    	width: 400px;
    	height: 100px;
    	font-family: "微软雅黑";
    	font-size: 20px;
    	margin: 30px auto;
    	text-align: center;
    }
    .icon{
    	display: block;
    }
</style>
