export function getCustomrColumns(){
  return [
    {title: '公司名称',key: 'partnerName', width : 100}, 
    {title: '账号', key: 'inviteMobile', width:100},
    {title: '联系人',key: 'partnerLinkName', width : 100}, 
    {title: '联系电话',key: 'partnerLinkMobile', width : 100},
    {title: '所在地',key: 'partnerArea', width : 100}, 
  ]
}