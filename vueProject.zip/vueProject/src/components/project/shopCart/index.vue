<template>
	<div>
		我是购物车
	</div>
</template>

<script>
</script>

<style>
</style>