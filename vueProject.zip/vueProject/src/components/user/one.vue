<template>
	<div>
		user one page<br /><br />
		
		<router-link to="/user/two">is to usertwo</router-link>
	</div>
</template>

<script>
</script>

<style>
</style>