import Vue from 'vue'
 
 var connector = new Vue();
  
export default connector;
